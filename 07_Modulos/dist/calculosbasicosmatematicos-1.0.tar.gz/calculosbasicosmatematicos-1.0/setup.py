from setuptools import setup

setup(

    name="calculosbasicosmatematicos",
    version="1.0",
    description="Paquete para cálculos básicos, suma, resta, multiplicación",
    author="Silvestre",
    author_email="silvestre.hdz.h@gmail.com",
    url="www.silvestrehdz.com",
    packages=["moduloMatematico", "moduloMatematico.calculosBasicos"]

)